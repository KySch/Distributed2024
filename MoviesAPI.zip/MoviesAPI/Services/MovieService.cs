﻿namespace MoviesAPI.Services
{
    public class MovieService
    {
    }
}
